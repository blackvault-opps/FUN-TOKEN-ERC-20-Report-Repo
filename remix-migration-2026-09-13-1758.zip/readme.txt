Remix migration archive.

Exported from https://remix.ethereum.org on 2026-09-13T21:58:19.896Z.
44 files, 203108 bytes, 43 settings.

files/       your workspaces, byte for byte
settings.json  your Remix preferences (no credentials)
manifest.json  file list with a SHA-256 per file

Import it with "Move your workspaces" in the workspace menu.
Keep this file until you have confirmed your workspaces opened correctly.
